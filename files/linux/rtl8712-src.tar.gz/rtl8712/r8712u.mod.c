#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

MODULE_INFO(staging, "Y");

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x2be3420e, "module_layout" },
	{ 0x12da5bb2, "__kmalloc" },
	{ 0xf9a482f9, "msleep" },
	{ 0x2b688622, "complete_and_exit" },
	{ 0xfbc74f64, "__copy_from_user" },
	{ 0x3ec8886f, "param_ops_int" },
	{ 0x67c2fa54, "__copy_to_user" },
	{ 0xd8f795ca, "del_timer" },
	{ 0x97255bdf, "strlen" },
	{ 0x3f622922, "dev_set_drvdata" },
	{ 0x2abe4593, "find_vpid" },
	{ 0x222227eb, "malloc_sizes" },
	{ 0x47939e0d, "__tasklet_hi_schedule" },
	{ 0xd6ab9567, "netif_carrier_on" },
	{ 0x3f38b182, "skb_clone" },
	{ 0x11f7ed4c, "hex_to_bin" },
	{ 0x8949858b, "schedule_work" },
	{ 0xb0bb9c02, "down_interruptible" },
	{ 0x801800be, "netif_carrier_off" },
	{ 0x8bef5b03, "usb_kill_urb" },
	{ 0x353e3fa5, "__get_user_4" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x74c86cc0, "init_timer_key" },
	{ 0x3c2c5af5, "sprintf" },
	{ 0x58912c3d, "kthread_create_on_node" },
	{ 0x7d11c268, "jiffies" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x810b3618, "param_ops_string" },
	{ 0xc7b763fe, "__netdev_alloc_skb" },
	{ 0x79d2b720, "netif_rx" },
	{ 0xe707d823, "__aeabi_uidiv" },
	{ 0x72aa82c6, "param_ops_charp" },
	{ 0xfa2a45e, "__memzero" },
	{ 0x5addde54, "skb_queue_purge" },
	{ 0x5f754e5a, "memset" },
	{ 0xa953fbc0, "dev_alloc_skb" },
	{ 0xdf209e8d, "usb_deregister" },
	{ 0x27e1a049, "printk" },
	{ 0x71c90087, "memcmp" },
	{ 0x22bfdee8, "free_netdev" },
	{ 0x328a05f1, "strncpy" },
	{ 0x318df52, "register_netdev" },
	{ 0x78111225, "wireless_send_event" },
	{ 0xc4f9f946, "usb_control_msg" },
	{ 0x16305289, "warn_slowpath_null" },
	{ 0x1e361bf6, "skb_push" },
	{ 0x9545af6d, "tasklet_init" },
	{ 0x9a6221c5, "mod_timer" },
	{ 0x2ff83914, "kill_pid" },
	{ 0x3ce3b997, "skb_pull" },
	{ 0xf285e091, "dev_kfree_skb_any" },
	{ 0xd79b5a02, "allow_signal" },
	{ 0xcd5a385b, "skb_queue_tail" },
	{ 0x6194da4e, "netif_device_attach" },
	{ 0x1257b7ea, "usb_submit_urb" },
	{ 0x26c5d0eb, "kmem_cache_alloc" },
	{ 0xbc10dd97, "__put_user_4" },
	{ 0xd49c9df4, "netif_device_detach" },
	{ 0xff8ddf2, "usb_get_dev" },
	{ 0x7d37b537, "usb_reset_device" },
	{ 0x6967de20, "usb_put_dev" },
	{ 0x6ece8976, "eth_type_trans" },
	{ 0x1f70a46, "wake_up_process" },
	{ 0x37a0cba, "kfree" },
	{ 0x9d669763, "memcpy" },
	{ 0x801678, "flush_scheduled_work" },
	{ 0xf10a2923, "dev_alloc_name" },
	{ 0x8cf51d15, "up" },
	{ 0x5dd66d8d, "usb_register_driver" },
	{ 0xb9ecd12d, "request_firmware" },
	{ 0x32fcd009, "skb_dequeue" },
	{ 0x4156f0d8, "unregister_netdev" },
	{ 0x701d0ebd, "snprintf" },
	{ 0x4e1f47c5, "__netif_schedule" },
	{ 0x333783e5, "skb_put" },
	{ 0x28f5a16c, "skb_copy_bits" },
	{ 0xafd0bdd0, "dev_get_drvdata" },
	{ 0x3303144, "usb_free_urb" },
	{ 0xdd692e22, "release_firmware" },
	{ 0xdc43a9c8, "daemonize" },
	{ 0xfd82b6af, "usb_alloc_urb" },
	{ 0x5c6391fe, "alloc_etherdev_mqs" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

MODULE_ALIAS("usb:v0BDAp8171d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0BDAp8173d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0BDAp8712d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0BDAp8713d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0BDApC512d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v07B8p8188d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0B05p1786d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0B05p1791d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v050Dp945Ad*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v07AAp0047d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v2001p3306d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v07D1p3306d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v7392p7611d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v1740p9603d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0E66p0016d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v06F8pE034d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v06F8pE032d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0789p0167d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v2019pAB28d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v2019pED16d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0DF6p0057d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0DF6p0045d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0DF6p0059d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0DF6p004Bd*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0DF6p005Dd*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0DF6p0063d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v177Fp0154d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0BDAp5077d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v1690p0752d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v20F4p646Bd*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v083ApC512d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0BDAp8172d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0EB0p9061d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0BDAp8172d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3323d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3311d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3342d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3333d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3334d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3335d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3336d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3309d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v050Dp815Fd*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v07D1p3302d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v07D1p3300d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v07D1p3303d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v7392p7612d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v1740p9605d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v06F8pE031d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0E66p0015d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3306d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v2019pED18d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v2019p4901d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0DF6p0058d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0DF6p0049d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0DF6p004Cd*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0DF6p0064d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v14B2p3300d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v14B2p3301d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v14B2p3302d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v04F2pAFF2d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v04F2pAFF5d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v04F2pAFF6d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3339d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3340d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3341d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3310d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v13D3p3325d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0BDAp8174d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0BDAp8174d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v050Dp845Ad*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v07AAp0051d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v7392p7622d*dc*dsc*dp*ic*isc*ip*");
MODULE_ALIAS("usb:v0409p02B6d*dc*dsc*dp*ic*isc*ip*");

MODULE_INFO(srcversion, "74C5D83AFDEB200D962475F");
